﻿using CryptographyHelper.Certificates;

namespace ClassifiedAds.Services.Configuration.ConfigurationOptions
{
    public class CertificatesOptions
    {
        public CertificateOption SettingsEncryption { get; set; }
    }
}
