﻿namespace ClassifiedAds.Infrastructure.Localization
{
    public class LocalizationProviders
    {
        public SqlServerOptions SqlServer { get; set; }
    }
}
