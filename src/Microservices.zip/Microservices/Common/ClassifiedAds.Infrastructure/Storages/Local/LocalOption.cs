﻿namespace ClassifiedAds.Infrastructure.Storages.Local
{
    public class LocalOption
    {
        public string Path { get; set; }
    }
}
