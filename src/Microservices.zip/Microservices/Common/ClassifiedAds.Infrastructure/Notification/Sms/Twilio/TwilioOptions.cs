﻿namespace ClassifiedAds.Infrastructure.Notification.Sms.Twilio
{
    public class TwilioOptions
    {
        public string AccountSId { get; set; }

        public string AuthToken { get; set; }

        public string FromNumber { get; set; }
    }
}
