﻿namespace ClassifiedAds.Infrastructure.Notification.Sms.Azure
{
    public class AzureOptions
    {
        public string ConnectionString { get; set; }
        public string FromNumber { get; set; }
    }
}
