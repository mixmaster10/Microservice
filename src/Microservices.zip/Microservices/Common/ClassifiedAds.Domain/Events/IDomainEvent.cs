﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassifiedAds.Domain.Events
{
    public interface IDomainEvent
    {
    }
}
