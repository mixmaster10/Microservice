﻿namespace ClassifiedAds.Domain.Entities
{
    public abstract class AggregateRoot<TKey> : Entity<TKey>
    {
    }
}
