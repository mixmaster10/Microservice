﻿namespace ClassifiedAds.Application
{
    public interface ICommand
    {
    }
}
