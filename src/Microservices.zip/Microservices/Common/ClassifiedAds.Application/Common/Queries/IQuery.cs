﻿namespace ClassifiedAds.Application
{
    public interface IQuery<TResult>
    {
    }
}
