﻿using System;

namespace ClassifiedAds.Application.Common.DTOs
{
    public class QueueItem
    {
        public Guid Id { get; set; }
    }
}
