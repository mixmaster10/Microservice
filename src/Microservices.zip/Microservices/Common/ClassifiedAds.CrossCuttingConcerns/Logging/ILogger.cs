﻿namespace ClassifiedAds.CrossCuttingConcerns.Logging
{
    public interface ILogger
    {
    }
}
