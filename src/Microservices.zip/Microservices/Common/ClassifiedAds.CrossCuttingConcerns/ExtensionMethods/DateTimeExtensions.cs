﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassifiedAds.CrossCuttingConcerns.ExtensionMethods
{
    public static class DateTimeExtensions
    {

    }
}
