﻿using CryptographyHelper.Certificates;

namespace ClassifiedAds.IdentityServer.ConfigurationOptions
{
    public class CertificatesOptions
    {
        public CertificateOption Default { get; set; }
    }
}
