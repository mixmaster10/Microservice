﻿namespace ClassifiedAds.IdentityServer.ConfigurationOptions.ExternalLogin
{
    public class FacebookOptions
    {
        public bool IsEnabled { get; set; }

        public string AppId { get; set; }

        public string AppSecret { get; set; }
    }
}
