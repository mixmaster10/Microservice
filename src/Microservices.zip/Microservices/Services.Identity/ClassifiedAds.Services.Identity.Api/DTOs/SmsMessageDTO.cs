﻿namespace ClassifiedAds.Services.Identity.DTOs
{
    public class SmsMessageDTO
    {
        public string Message { get; set; }

        public string PhoneNumber { get; set; }
    }
}
